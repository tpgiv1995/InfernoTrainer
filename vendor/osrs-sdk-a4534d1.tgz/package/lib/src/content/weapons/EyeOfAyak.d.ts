import { AttackStyle, AttackStyleTypes } from "../../sdk/AttackStylesController";
import { AttackBonuses } from "../../sdk/gear/Weapon";
import { ItemName } from "../../sdk/ItemName";
import { Unit } from "../../sdk/Unit";
import { MagicWeapon } from "../../sdk/weapons/MagicWeapon";
import { ProjectileOptions } from "../../sdk/weapons/Projectile";
/**
 * Eye of Ayak: a one-handed powered staff, 3-tick attack speed, with its own max hit
 * (floor(Magic / 3) - 6, plus the Magic damage bonus). Soul Rend, its special attack, costs 50% energy, takes
 * 5 ticks, doubles the attack roll, raises the max hit by 30%, and lowers the target's Magic defence bonus
 * by the damage it deals. Numbers follow tools/inferno_gear.py (eye_max, magic_attack_roll).
 */
export declare class EyeOfAyak extends MagicWeapon {
    /** Set while the swing in flight is Soul Rend, so the next attack delay is 5 ticks. */
    private lastSwingWasSpec;
    constructor();
    get itemName(): ItemName;
    get weight(): number;
    get inventoryImage(): string;
    get isTwoHander(): boolean;
    attackStyles(): AttackStyle[];
    attackStyleCategory(): AttackStyleTypes;
    defaultStyle(): AttackStyle;
    get attackRange(): 6 | 8;
    get attackSpeed(): 3 | 5;
    hasSpecialAttack(): boolean;
    specialAttackDrain(): number;
    attack(from: Unit, to: Unit, bonuses?: AttackBonuses, options?: ProjectileOptions): boolean;
    specialAttack(from: Unit, to: Unit, bonuses?: AttackBonuses, options?: ProjectileOptions): void;
    _attackRoll(from: Unit, to: Unit, bonuses: AttackBonuses): number;
    /** Magic damage bonus in tenths of a percent: worn gear (stored as 1 + sum of fractions) plus the prayer. */
    magicDamageTenths(from: Unit, bonuses: AttackBonuses): number;
    _maxHit(from: Unit, to: Unit, bonuses: AttackBonuses): number;
    grantXp(from: Unit, to: Unit): void;
}
