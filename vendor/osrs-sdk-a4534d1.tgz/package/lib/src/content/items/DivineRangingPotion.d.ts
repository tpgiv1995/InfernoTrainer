import { ItemName } from "../../sdk/ItemName";
import { Player } from "../../sdk/Player";
import { Potion } from "../../sdk/gear/Potion";
/** See drink(). */
export declare class DivineRangingPotion extends Potion {
    oneDose: HTMLImageElement;
    twoDose: HTMLImageElement;
    threeDose: HTMLImageElement;
    fourDose: HTMLImageElement;
    constructor(doses?: number);
    get inventoryImage(): string;
    get itemName(): ItemName;
    /**
     * Divine ranging potion: Ranged +4 and +10%, costs 10% of Hitpoints, and holds the boost at full strength for
     * 5 minutes (500 ticks): a Saradomin brew's Ranged drain cannot pull it below the boosted level meanwhile.
     */
    drink(player: Player): void;
    updateInventorySprite(): void;
}
