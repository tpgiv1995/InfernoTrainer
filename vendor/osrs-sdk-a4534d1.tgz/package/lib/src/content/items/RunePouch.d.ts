import { Item } from "../../sdk/Item";
import { ItemName } from "../../sdk/ItemName";
/** Rune pouch holding the Ice and Blood Barrage runes. The sim's spellbook casts without rune counts, so it is inert. */
export declare class RunePouch extends Item {
    inventorySprite: HTMLImageElement;
    constructor();
    get inventoryImage(): string;
    get itemName(): ItemName;
    get weight(): number;
}
