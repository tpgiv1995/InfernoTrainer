import { Ammo, AmmoType } from "../../sdk/gear/Ammo";
import { ItemName } from "../../sdk/ItemName";
/** Rada's blessing 4: +2 prayer bonus, worn in the ammo slot like the Holy blessing. */
export declare class RadasBlessing4 extends Ammo {
    inventorySprite: HTMLImageElement;
    get inventoryImage(): string;
    get itemName(): ItemName;
    get weight(): number;
    ammoType(): AmmoType;
    constructor();
}
