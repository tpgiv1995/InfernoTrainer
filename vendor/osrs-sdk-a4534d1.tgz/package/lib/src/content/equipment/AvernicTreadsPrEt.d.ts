import { Feet } from "../../sdk/gear/Feet";
import { ItemName } from "../../sdk/ItemName";
/** V3 Inferno kit item. Stats are the OSRS Wiki values the calculator (tools/inferno_gear.py) reads. */
export declare class AvernicTreadsPrEt extends Feet {
    inventorySprite: HTMLImageElement;
    get inventoryImage(): string;
    get itemName(): ItemName;
    get weight(): number;
    constructor();
}
