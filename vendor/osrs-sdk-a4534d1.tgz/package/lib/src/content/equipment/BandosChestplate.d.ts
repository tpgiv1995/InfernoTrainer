import { Chest } from "../../sdk/gear/Chest";
import { ItemName } from "../../sdk/ItemName";
/** V3 Inferno kit item. Stats are the OSRS Wiki values the calculator (tools/inferno_gear.py) reads. */
export declare class BandosChestplate extends Chest {
    inventorySprite: HTMLImageElement;
    get inventoryImage(): string;
    get itemName(): ItemName;
    get weight(): number;
    constructor();
}
