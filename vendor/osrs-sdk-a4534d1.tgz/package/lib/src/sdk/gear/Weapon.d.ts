import { BasePrayer } from "../BasePrayer";
import { Unit } from "../Unit";
import { Equipment } from "../Equipment";
import { Player } from "../Player";
import { ProjectileOptions } from "../weapons/Projectile";
import { ItemName } from "../ItemName";
import { AttackStyle, AttackStyleTypes } from "../AttackStylesController";
import { Sound } from "../utils/SoundCache";
import { PlayerAnimationIndices } from "../rendering/GLTFAnimationConstants";
interface EffectivePrayers {
    magic?: BasePrayer;
    range?: BasePrayer;
    attack?: BasePrayer;
    strength?: BasePrayer;
    defence?: BasePrayer;
    overhead?: BasePrayer;
}
export interface AttackBonuses {
    styleBonus?: number;
    isAccurate?: boolean;
    styleStrengthBonus?: number;
    voidMultiplier?: number;
    gearMeleeMultiplier?: number;
    gearMageMultiplier?: number;
    gearRangeMultiplier?: number;
    attackStyle?: string;
    magicBaseSpellDamage?: number;
    overallMultiplier?: number;
    effectivePrayers?: EffectivePrayers;
    isSpecialAttack?: boolean;
}
export declare class Weapon extends Equipment {
    protected projectileOptions: ProjectileOptions;
    damage: number;
    damageRoll: number;
    lastHitHit: boolean;
    selected: boolean;
    inventorySprite: HTMLImageElement;
    constructor(projectileOptions?: ProjectileOptions);
    attackStyles(): any[];
    compatibleAmmo(): ItemName[];
    attackStyleCategory(): AttackStyleTypes;
    defaultStyle(): AttackStyle;
    attackStyle(): AttackStyle;
    assignToPlayer(player: Player): void;
    unassignToPlayer(player: Player): void;
    currentEquipment(player: Player): Equipment;
    hasSpecialAttack(): boolean;
    specialAttackDrain(): number;
    specialAttack(from: Unit, to: Unit, bonuses?: AttackBonuses, options?: ProjectileOptions): void;
    inventoryLeftClick(player: Player): void;
    cast(from: Unit, to: Unit): void;
    rollDamage(from: Unit, to: Unit, bonuses: AttackBonuses): void;
    calculateHitDelay(distance: number): number;
    attack(from: Unit, to: Unit, bonuses?: AttackBonuses, options?: ProjectileOptions): boolean;
    _rollAttack(from: Unit, to: Unit, bonuses: AttackBonuses): number;
    _calculateHitDamage(from: Unit, to: Unit, bonuses: AttackBonuses): number;
    _attackRoll(from: Unit, to: Unit, bonuses: AttackBonuses): number;
    _defenceRoll(from: Unit, to: Unit, bonuses: AttackBonuses): number;
    _maxHit(from: Unit, to: Unit, bonuses: AttackBonuses): number;
    _hitChance(from: Unit, to: Unit, bonuses: AttackBonuses): number;
    /** Wiki DPS calculator hit chance. Weapons with a re-roll rule (Confliction gauntlets) override this. */
    _v3HitChance(from: Unit, to: Unit, attackRoll: number, defenceRoll: number, bonuses: AttackBonuses): number;
    isBlockable(from: Unit, to: Unit, bonuses: AttackBonuses): boolean;
    grantXp(from: Unit, to: Unit): void;
    _calculatePrayerEffects(from: Unit, to: Unit, bonuses: AttackBonuses): void;
    registerProjectile(from: Unit, to: Unit, bonuses: AttackBonuses, options?: ProjectileOptions): void;
    get image(): HTMLImageElement;
    get attackRange(): number;
    get attackSpeed(): number;
    get aoe(): {
        x: number;
        y: number;
    }[];
    get isAreaAttack(): boolean;
    get isMeleeAttack(): boolean;
    get isTwoHander(): boolean;
    static isMeleeAttackStyle(style: string): boolean;
    get attackSound(): Sound | null;
    get specialAttackSound(): Sound | null;
    get attackLandingSound(): Sound | null;
    get projectileModel(): string | null;
    get idleAnimationId(): PlayerAnimationIndices;
}
export {};
