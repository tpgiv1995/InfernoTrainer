/**
 * OSRS cache item ids for everything the V3 Inferno player can wear or wield, plus the semantic pose map.
 * Shared by the browser runtime and the Node-only extractor (scripts/player-render), so keep it free of imports.
 */
export declare const PLAYER_CACHE_ITEMS: {
    readonly bloodAncientSceptre: {
        readonly id: 28260;
    };
    readonly crystalShield: {
        readonly id: 23991;
    };
    readonly guthansHelm: {
        readonly id: 4724;
    };
    readonly occultNecklace: {
        readonly id: 12002;
    };
    readonly imbuedSaradominCape: {
        readonly id: 21791;
    };
    readonly radasBlessing4: {
        readonly id: 22947;
    };
    readonly bandosChestplate: {
        readonly id: 11832;
    };
    readonly oathplateLegs: {
        readonly id: 30756;
    };
    readonly conflictionGauntlets: {
        readonly id: 31106;
    };
    readonly avernicTreadsPrEt: {
        readonly id: 31095;
    };
    readonly magusRing: {
        readonly id: 28313;
    };
    readonly bowOfFaerdhinenC: {
        readonly id: 25886;
    };
    readonly crystalHelm: {
        readonly id: 27729;
    };
    readonly crystalBody: {
        readonly id: 27721;
    };
    readonly crystalLegs: {
        readonly id: 27725;
    };
    readonly dizanasQuiver: {
        readonly id: 28951;
    };
    readonly necklaceOfRupture: {
        readonly id: 33639;
    };
    readonly toxicBlowpipe: {
        readonly id: 12926;
    };
    readonly eyeOfAyak: {
        readonly id: 31113;
    };
};
/** Default male appearance: one identity kit per body part (OSRS kit ids). */
export declare const PLAYER_DEFAULT_KIT: {
    readonly head: {
        readonly kit: 0;
        readonly slot: 8;
    };
    readonly jaw: {
        readonly kit: 10;
        readonly slot: 11;
    };
    readonly torso: {
        readonly kit: 18;
        readonly slot: 4;
    };
    readonly arms: {
        readonly kit: 26;
        readonly slot: 6;
    };
    readonly hands: {
        readonly kit: 33;
        readonly slot: 9;
    };
    readonly legs: {
        readonly kit: 36;
        readonly slot: 7;
    };
    readonly feet: {
        readonly kit: 42;
        readonly slot: 10;
    };
};
export declare const PLAYER_ANIMATION_SEQUENCES: Record<number, number>;
/**
 * Cache spotanim (graphic) ids for the V3 kit's projectiles and impacts. Sources: RuneLite gameval SpotanimID and the
 * cache's own spotanim definitions (model, sequence and length checked against the weapon's tick speed).
 */
export declare const PLAYER_CACHE_SPOTANIMS: {
    readonly bofaArrowTravel: 1926;
    readonly bofaArrowLaunch: 1927;
    readonly iceBarrageImpact: 369;
    readonly bloodBarrageImpact: 377;
    readonly splash: 85;
    readonly ayakSpecialPlayer: 3364;
    readonly ayakSpecialImpact: 3365;
    readonly ayakNormalPlayer: 3366;
    readonly ayakNormalProjectile: 3367;
    readonly ayakNormalImpact: 3368;
};
