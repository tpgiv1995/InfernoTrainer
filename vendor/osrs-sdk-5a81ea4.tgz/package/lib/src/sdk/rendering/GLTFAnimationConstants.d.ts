export declare enum PlayerAnimationIndices {
    Idle = 0,
    Walk = 1,
    Run = 2,
    Rotate180 = 3,
    StrafeLeft = 4,
    StrafeRight = 5,
    FireBow = 6,
    FireBlowpipe = 7,
    ThrowChinchompa = 8,
    ScytheIdle = 9,
    ScytheSwing = 10,
    SwordSlash = 11,
    CastStaff = 12,
    CastBarrage = 13,
    EyeOfAyakNormal = 14,
    EyeOfAyakSpecial = 15
}
