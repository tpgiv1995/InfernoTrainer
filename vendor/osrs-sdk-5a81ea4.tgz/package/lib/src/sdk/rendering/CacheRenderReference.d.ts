/** A semantic reference to cache-derived render data. */
export type CacheRenderReference = {
    kind: "npc";
    definitionId: number;
    spotAnims?: CacheRenderSpotAnim[];
    bundleId?: string;
} | {
    kind: "model";
    modelId: number;
    bundleId?: string;
}
/** A precomposed cache payload, used by compiled static scene recipes. */
 | {
    kind: "asset";
    assetId: string;
    bundleId?: string;
} | {
    kind: "spotAnim";
    spotAnims: CacheRenderSpotAnim[];
    bundleId?: string;
} | {
    kind: "player";
    loadout: Array<string | number>;
    poses?: Record<string, number>;
    spotAnims?: CacheRenderSpotAnim[];
    bundleId?: string;
};
/** Runtime placement/timing for a cache-derived effect. The cache stores the
 * effect model and sequence, but actor-specific height, offset, and delay are
 * supplied by gameplay code. */
export type CacheRenderSpotAnim = {
    id: number;
    /** Optional replacement channel for mutually exclusive effects. */
    channel?: string;
    /** Semantic player animation that activates this effect. */
    animation?: number;
    height?: number;
    /** Tile-plane world offset from the player (x/east, y/north). */
    offset?: {
        x: number;
        y: number;
    };
    delay?: number;
    rotation?: number;
    /** Highest opacity (0..1) any face of this effect may have. Keeps large single-colour effects see-through. */
    opacityCap?: number;
    /** Optional mapping from cache HSL face colours to Three.js RGB values. */
    recolor?: Record<string, number>;
};
/** Stable semantic key for item references; display-name casing/punctuation is not significant. */
export declare function cacheRenderItemKey(item: string | number): string;
export declare const CacheRenderReferences: {
    npc(definitionId: number, spotAnimsOrBundleId?: CacheRenderSpotAnim[] | string, bundleId?: string): CacheRenderReference;
    model(modelId: number, bundleId?: string): CacheRenderReference;
    asset(assetId: string, bundleId?: string): CacheRenderReference;
    spotAnim(spotAnims: CacheRenderSpotAnim[], bundleId?: string): CacheRenderReference;
    player(loadout: Array<string | number>, poses?: Record<string, number>, spotAnimsOrBundleId?: CacheRenderSpotAnim[] | string, bundleId?: string): CacheRenderReference;
};
