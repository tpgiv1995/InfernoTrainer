import { GraphicsObject } from "./GraphicsObject";
import { Unit } from "./Unit";
import type { Projectile, ProjectileOptions } from "./weapons/Projectile";
/** Debug-only record of the graphics spawned (the browser smoke test reads it). */
export declare const V3GraphicsLog: {
    enabled: boolean;
    graphics: {
        id: number;
        height: number;
    }[];
};
/** Real projectile and impact graphics (cache spotanims) are a V3 feature that needs the cache bundle. */
export declare function v3GraphicsEnabled(): boolean;
/**
 * Plays a cache graphic once at a unit (the client's "spotanim on an actor"). `height` is in tile units above the
 * unit's feet. Does nothing unless the V3 graphics are enabled.
 */
export declare function spawnGraphic(at: Unit, spotAnimId: number, height?: number, opacityCap?: number): GraphicsObject | null;
/** Projectile options that draw the projectile from a cache spotanim. */
export declare function spotAnimProjectile(id: number): Partial<ProjectileOptions>;
/** Runs `fn` when the projectile lands (same hook the V3 lifesteal uses), chaining any earlier hook. */
export declare function withImpact(options: ProjectileOptions, fn: (projectile: Projectile) => void): ProjectileOptions;
