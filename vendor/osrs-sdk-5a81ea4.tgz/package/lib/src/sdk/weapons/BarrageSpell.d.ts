import { Unit } from "../Unit";
import { MagicWeapon } from "./MagicWeapon";
import { ProjectileOptions } from "./Projectile";
import { AttackBonuses } from "../gear/Weapon";
import { AttackStyle } from "../AttackStylesController";
export declare class BarrageSpell extends MagicWeapon {
    get aoe(): {
        x: number;
        y: number;
    }[];
    get attackRange(): number;
    get attackSpeed(): number;
    get maxConcurrentHits(): number;
    attackStyle(): AttackStyle;
    /** Cache graphic played on every target the spell lands on (Ice Barrage 369, Blood Barrage 377). */
    get impactSpotAnim(): number;
    /**
     * The ice column is one flat colour, drawn unlit it would be a solid slab hiding the monsters; cap its opacity so the
     * target stays visible through it.
     */
    get impactOpacityCap(): number | undefined;
    /**
     * V3: the barrages have no projectile in the game, only an impact graphic on each target when the spell lands
     * (the splash graphic when it does no damage), on the same tick the damage applies.
     */
    registerProjectile(from: Unit, to: Unit, bonuses: AttackBonuses, options?: ProjectileOptions): void;
    /** Base max hit before magic damage bonuses (wiki): Ice Barrage 30, Blood Barrage 29. */
    get baseDamage(): number;
    cast(from: Unit, to: Unit): boolean;
    attack(from: Unit, to: Unit, bonuses?: AttackBonuses, options?: ProjectileOptions): boolean;
}
