import { BasePrayer } from "./BasePrayer";
import { Eating } from "./Eating";
import { Weapon } from "./gear/Weapon";
import { Item } from "./Item";
import { Location } from "./Location";
import { PlayerRegenTimer } from "./PlayerRegenTimers";
import { PlayerStats } from "./PlayerStats";
import { Region } from "./Region";
import { Unit, UnitBonuses, UnitOptions, UnitTypes } from "./Unit";
import { Sound } from "./utils/SoundCache";
import { XpDrop, XpDropAggregator } from "./XpDrop";
import { TileMarker } from "../content/TileMarker";
import { Model } from "./rendering/Model";
import { PlayerAnimationIndices } from "./rendering/GLTFAnimationConstants";
declare class PlayerEffects {
    poisoned: number;
    venomed: number;
    stamina: number;
}
export declare class Player extends Unit {
    manualSpellCastSelection: Weapon;
    destinationLocation?: Location;
    pathTargetLocation?: Location;
    stats: PlayerStats;
    currentStats: PlayerStats;
    xpDrops: XpDropAggregator;
    overhead: BasePrayer;
    running: boolean;
    cachedBonuses: UnitBonuses;
    useSpecialAttack: boolean;
    effects: PlayerEffects;
    regenTimer: PlayerRegenTimer;
    autocastDelay: number;
    manualCastHasTarget: boolean;
    eats: Eating;
    inventory: Item[];
    seekingItem: Item;
    path: (Location & {
        run: boolean;
    })[];
    clickMarker: ClickMarker | null;
    aggroMarker: ClickMarker | null;
    pathMarkers: ClickMarker[];
    currentPoseAnimation: PlayerAnimationIndices;
    constructor(region: Region, location: Location, options?: UnitOptions);
    contextActions(region: Region, x: number, y: number): any[];
    setUnitOptions(options: UnitOptions): void;
    interruptCombat(): void;
    get color(): string;
    get height(): number;
    get isPlayer(): boolean;
    get attackRange(): number;
    get attackSpeed(): number;
    openInventorySlots(): number[];
    swapItemPositions(pos1: number, pos2: number): void;
    equipmentChanged(): void;
    get bonuses(): UnitBonuses;
    setStats(): void;
    get weight(): number;
    get prayerDrainResistance(): number;
    get type(): UnitTypes;
    clearXpDrops(): void;
    grantXp(xpDrop: XpDrop): void;
    sendXpToController(): void;
    moveTo(x: number, y: number): void;
    attack(): boolean;
    activatePrayers(): void;
    setAggro(mob: Unit): void;
    setSeekingItem(item: Item): void;
    determineDestination(): void;
    private getIdlePoseId;
    clientTick(tickPercent: any): void;
    moveTowardsDestination(): void;
    takeSeekingItem(): void;
    dead(): void;
    private restingAngle;
    private nextAngle;
    private _angle;
    private lastTickPercent;
    getPerceivedRotation(tickPercent: any): number;
    getTargetAngle(): number;
    movementStep(): void;
    removeClickMarker(): void;
    updatePathMarker(): void;
    hitSound(damaged: boolean): Sound | null;
    damageTaken(): void;
    pretick(): void;
    v3TickCount: number;
    saturatedHeart: {
        level: number;
        expires: number;
    } | null;
    saturatedHeartCooldownUntil: number;
    prayerRegenTicksLeft: number;
    /** True while the Saturated heart is on cooldown (5 minutes from the use, 500 ticks). */
    get saturatedHeartOnCooldown(): boolean;
    /**
     * Saturated heart: +4 and +10% Magic for 5 minutes, and the boost does not decay. Anything that drags Magic
     * below the boosted level (a Saradomin brew) cancels it. Returns false while it is on cooldown.
     */
    useSaturatedHeart(): boolean;
    /**
     * Divine potions: the boost does not decay for 5 minutes, then the stat drops back to base. Other drains (a
     * Saradomin brew) still lower it normally, and drinking again re-boosts and restarts the 5 minutes.
     */
    heldStats: {
        [stat: string]: {
            level: number;
            expires: number;
        };
    };
    holdStat(stat: "attack" | "strength" | "defence" | "range" | "magic", level: number, ticks: number): void;
    v3ApplyHolds(): void;
    /** Cancel the heart if a drain pulled Magic below its level, end it when the 5 minutes are up. */
    v3CheckHeart(): void;
    /** Boosts decay one level a minute (100 ticks), except the Saturated heart's Magic and a Divine potion's stat. */
    v3DecayBoosts(): void;
    v3Tick(): void;
    attackStep(): void;
    attackIfPossible(): void;
    draw(tickPercent: number): {
        x: number;
        y: number;
    };
    getPerceivedLocation(tickPercent: number): {
        z: number;
        x: number;
        y: number;
    };
    drawUILayer(tickPercent: number, offset: Location, context: OffscreenCanvasRenderingContext2D, scale: number, hitsplatsAbove: boolean): void;
    create3dModel(): Model;
    get animationIndex(): PlayerAnimationIndices;
    get drawOutline(): boolean;
    get attackAnimationId(): number;
    get canBlendAttackAnimation(): boolean;
    get drawTrueTile(): boolean;
    get trueTileRenderOrder(): number;
    get deathAnimationLength(): number;
}
declare class ClickMarker extends TileMarker {
    constructor(region: Region, location: Location, color?: string);
    remove(): void;
}
export {};
