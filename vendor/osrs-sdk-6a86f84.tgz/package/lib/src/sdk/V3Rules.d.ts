import type { Unit } from "./Unit";
import type { BasePrayer } from "./BasePrayer";
/**
 * V3 Inferno Sim combat rules. They reproduce the OSRS Wiki DPS calculator (hit chance, effective levels,
 * prayer factors, the player's defence roll against monsters) so the sim can be checked number for number
 * against tools/inferno_gear.py. Set `V3Rules.calculator = false` to get upstream 0.1.4's original formulas
 * back; the golden-flow tests use that to prove the untouched mechanics still match upstream.
 */
export declare class V3Rules {
    static calculator: boolean;
}
/** Integer-safe `floor(value * numerator / denominator)`. */
export declare function fac(value: number, numerator: number, denominator?: number): number;
/** floor(value * multiplier) for multipliers that are sums of decimal fractions (exact to a thousandth, no float drift). */
export declare function mulFloor(value: number, multiplier: number): number;
/** Eye of Ayak max hit (calculator eye_max): floor(Magic / 3) - 6 (at least 1), x1.3 for Soul Rend, then + the damage bonus. */
export declare function eyeMax(magic: number, dmgTenths: number, spec?: boolean): number;
/** Wiki hit chance: attack roll a against defence roll d. */
export declare function stdRoll(a: number, d: number): number;
/** Chance of landing when the attack rolls accuracy twice and keeps the better roll (Confliction gauntlets). */
export declare function fangRoll(a: number, d: number): number;
export interface PrayerFactor {
    /** Magic accuracy as a percentage of the Magic level (115 = x1.15). */
    acc?: number;
    /** Magic damage bonus in tenths of a percent (30 = +3.0%). */
    mdmgTenths?: number;
    /** Magic defence factor applied to the Magic level (percentage). */
    mdef?: number;
    /** Defence level boost in percent (5 = +5%). */
    dfn?: number;
    /** Ranged accuracy factor (percentage). */
    racc?: number;
    /** Ranged strength factor (percentage). */
    rstr?: number;
}
/** Prayer factors, keyed by prayer name. Mystic Vigour, Deadeye, Mystic Might and Eagle Eye are the calculator's PRAYERS table. */
export declare const PRAYER_FACTORS: Record<string, PrayerFactor>;
/** Prayers that the Royal Titans scrolls permanently swap into the book (wiki "Prayer"). */
export declare const PRAYER_BOOK_OVERRIDES: Record<string, string>;
/** Rune costs (OSRS Wiki infoboxes). */
export declare const SPELL_RUNE_COSTS: Record<string, Record<string, number>>;
/**
 * Pays a spell's runes from the caster's rune pouch. With no pouch in the inventory the cast is free (upstream
 * loadouts); with one, it returns false at zero and nothing is spent.
 */
export declare function spendSpellRunes(caster: Unit, spell: string): boolean;
export declare function prayerFactor(prayer: BasePrayer | undefined | null): PrayerFactor;
/** The player's defence roll against an NPC attack (wiki NPCVsPlayerCalc): (8 + effective level) x (bonus + 64). */
export declare function playerDefenceRoll(player: Unit, style: "stab" | "slash" | "crush" | "range" | "magic", stanceBonus?: number): number;
/** The defence a player's combat stance adds to their defence level: Longrange and Defensive +3, Controlled +1. */
export declare function playerStanceDefenceBonus(player: Unit): number;
export declare function conflictionActive(from: Unit): boolean;
/** True when the last magic attack on this target missed and was made with the same weapon or spell. */
export declare function conflictionIsArmed(target: Unit, attackName: string): boolean;
/** Records the last magic attack on the target: the attack's name after a miss, null after a hit. */
export declare function setConflictionState(target: Unit, missedWith: string | null): void;
