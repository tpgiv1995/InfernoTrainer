import { CollisionType } from "./Collision";
import { Entity } from "./Entity";
import { LineOfSightMask } from "./LineOfSight";
import { Location } from "./Location";
import { Region } from "./Region";
export interface GraphicsObjectOptions {
    /** Vertical offset in SDK tile units. */
    height?: number;
    /** Delay before playback in 50 Hz client cycles. */
    delay?: number;
    /** Additional cache-angle rotation, where 2048 units is one turn. */
    rotation?: number;
    /** Highest opacity (0..1) any face may have. */
    opacityCap?: number;
    /** Optional mapping from cache HSL face colours to Three.js RGB values. */
    recolor?: Record<string, number>;
}
/**
 * A standalone, one-shot world instance of a cache spot-animation definition.
 *
 * This mirrors the client's GraphicsObject: the spotanim ID supplies its model,
 * sequence, scale, and cache rotation, while the spawn supplies world placement,
 * height, and delay. The entity removes itself when the sequence finishes.
 */
export declare class GraphicsObject extends Entity {
    readonly spotAnimId: number;
    private readonly options;
    private finished;
    constructor(region: Region, location: Location, spotAnimId: number, options?: GraphicsObjectOptions);
    get collisionType(): CollisionType;
    get lineOfSight(): LineOfSightMask;
    get drawOutline(): boolean;
    get color(): string;
    shouldDestroy(): boolean;
    create3dModel(): any;
    draw(): void;
}
