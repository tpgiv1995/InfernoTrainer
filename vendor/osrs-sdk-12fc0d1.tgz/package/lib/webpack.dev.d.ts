declare const _exports: {
    devtool: string;
    resolve: {
        extensions: string[];
    };
    optimization: {
        minimize: boolean;
    };
    module: {
        rules: ({
            test: RegExp;
            use: string;
            exclude: RegExp;
        } | {
            test: RegExp;
            type: string;
        } | {
            test: RegExp;
            loader: string;
        })[];
    };
};
export = _exports;
