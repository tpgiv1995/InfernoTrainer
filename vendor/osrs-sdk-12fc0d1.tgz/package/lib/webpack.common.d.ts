export const devtool: string;
export namespace resolve {
    const extensions: string[];
}
export namespace optimization {
    const minimize: boolean;
}
export namespace module {
    const rules: ({
        test: RegExp;
        use: string;
        exclude: RegExp;
        type?: undefined;
        loader?: undefined;
    } | {
        test: RegExp;
        type: string;
        use?: undefined;
        exclude?: undefined;
        loader?: undefined;
    } | {
        test: RegExp;
        loader: string;
        use?: undefined;
        exclude?: undefined;
        type?: undefined;
    })[];
}
