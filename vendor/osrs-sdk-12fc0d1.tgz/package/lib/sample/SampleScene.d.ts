import { Entity, CollisionType, LineOfSightMask, Model } from "../src";
export declare const SampleSceneModel: string;
export declare class SampleScene extends Entity {
    get collisionType(): CollisionType;
    get size(): number;
    draw(): void;
    get color(): string;
    get lineOfSight(): LineOfSightMask;
    getPerceivedRotation(): number;
    create3dModel(): Model;
}
