import { Mob } from "../src";
export declare class SampleNpc extends Mob {
    mobName(): string;
    get combatLevel(): number;
    setStats(): void;
    get bonuses(): {
        attack: {
            stab: number;
            slash: number;
            crush: number;
            magic: number;
            range: number;
        };
        defence: {
            stab: number;
            slash: number;
            crush: number;
            magic: number;
            range: number;
        };
        other: {
            meleeStrength: number;
            rangedStrength: number;
            magicDamage: number;
            prayer: number;
        };
    };
    get attackSpeed(): number;
    attackStyleForNewAttack(): string;
    get attackRange(): number;
    get size(): number;
    create3dModel(): any;
}
