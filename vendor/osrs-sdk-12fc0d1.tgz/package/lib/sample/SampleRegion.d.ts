import { CardinalDirection, Player, Region } from "../src";
export declare class SampleRegion extends Region {
    get initialFacing(): CardinalDirection;
    getName(): string;
    get width(): number;
    get height(): number;
    initialiseRegion(): {
        player: Player;
    };
}
