import { ClickController } from "./ClickController";
import { Player } from "./Player";
export declare class Trainer {
    static _player: Player;
    static _clickController: ClickController;
    static setClickController(clickController: ClickController): void;
    static setPlayer(player: Player): void;
    static get player(): Player;
    static get clickController(): ClickController;
    static reset(): void;
    private static deathListeners;
    private static resetListeners;
    static onPlayerDeath(listener: () => void): () => boolean;
    static onReset(listener: () => void): () => boolean;
    static notifyPlayerDeath(): void;
}
