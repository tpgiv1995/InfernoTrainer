import { PlayerStats } from "./PlayerStats";
import { Location } from "./Location";
import { PrayerLayout } from "./controlpanels/PrayerLayouts";
export declare class Settings {
    static zoomScale: number;
    static _tileSize: number;
    static get tileSize(): number;
    static fps: number;
    static tickMs: number;
    static playsAudio: boolean;
    static playsAreaAudio: boolean;
    static inputDelay: number;
    static rotated: string;
    static region: string;
    static displayXpDrops: boolean;
    static lockPOV: boolean;
    static displayFeedback: boolean;
    static metronome: boolean;
    static antiDrag: number;
    /** RuneLite resizable-modern layout: one bottom tab row, bigger panel, chat strip. */
    static modernLayout: boolean;
    /** Multiplier on mouse camera rotation speed. 1 = upstream default. */
    static cameraSensitivity: number;
    /** Custom prayer book slots (30 names, "" = empty) or null for the stock order. */
    static prayerLayout: PrayerLayout | null;
    static inventory_key: string;
    static spellbook_key: string;
    static equipment_key: string;
    static prayer_key: string;
    static combat_key: string;
    static tile_markers: Location[];
    static tileMarkerColor: string;
    static loadout: string;
    static onTask: boolean;
    static player_stats: PlayerStats;
    static is_keybinding: boolean;
    static southPillar: boolean;
    static westPillar: boolean;
    static northPillar: boolean;
    static displayPlayerLoS: boolean;
    static displayMobLoS: boolean;
    static menuVisible: boolean;
    static minimapScale: number;
    static controlPanelScale: number;
    static maxUiScale: number;
    static _isMobileResult: any;
    static use3dView: boolean;
    static isUsingWasdKeybind: boolean;
    private static checkWasd;
    static mobileCheck(): any;
    static persistToStorage(): void;
    private static readPrayerLayout;
    static read<T>(key: string, defaultValue: T): T;
    static readFromStorage(): void;
}
