export interface Location {
    x: number;
    y: number;
}
export interface Location3 {
    x: number;
    y: number;
    z: number;
}
export interface Locatable {
    location: Location;
    size: number;
}
export declare class LocationUtils {
    static closestPointTo(x: number, y: number, mob: Locatable): any;
    static dist(x: number, y: number, x2: number, y2: number): number;
    static angle(x: number, y: number, x2: number, y2: number): number;
}
