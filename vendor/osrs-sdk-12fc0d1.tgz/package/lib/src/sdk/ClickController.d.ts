import { ClickAnimation } from "./ClickAnimation";
import type { Unit } from "./Unit";
import { Viewport } from "./Viewport";
export declare class ClickController {
    clickAnimation?: ClickAnimation;
    viewport: Viewport;
    constructor(viewport: Viewport);
    eventListeners: ((e: MouseEvent) => void)[];
    private rightGesture;
    /** True while the right button is held and has moved past the drag threshold. */
    get isRightDragging(): boolean;
    /** Feed a mousemove to the right-drag gesture; safe to call from any listener order. */
    trackRightDrag(e: MouseEvent): boolean;
    unload(): void;
    registerClickActions(): void;
    wheel(e: WheelEvent): void;
    clickUp(e: MouseEvent): void;
    private recentlySelectedMobs;
    hasSelectedMob(): boolean;
    mouseMoved(e: MouseEvent): void;
    private getClickedOn;
    clickDown(e: MouseEvent): void;
    rightClickDown(e: MouseEvent): void;
    playerAttackClick(mob: Unit): void;
    playerWalkClick(x: number, y: number): void;
    redClick(): void;
    yellowClick(): void;
}
