import { AncientsSpellbookControls } from "./controlpanels/AncientsSpellbookControls";
import { BaseControls } from "./controlpanels/BaseControls";
import { CombatControls } from "./controlpanels/CombatControls";
import { EquipmentControls } from "./controlpanels/EquipmentControls";
import { InventoryControls } from "./controlpanels/InventoryControls";
import { PrayerControls } from "./controlpanels/PrayerControls";
import { SettingsControls } from "./controlpanels/SettingsControls";
import { StatsControls } from "./controlpanels/StatsControls";
import { Location } from "./Location";
interface TabPosition {
    x: number;
    y: number;
}
export declare const TAB_W = 33;
export declare const TAB_H = 36;
export declare const PANEL_W = 204;
export declare const PANEL_H = 275;
/** How much larger the modern layout draws the panel than maxUiScale alone. */
export declare const MODERN_SCALE_MULT = 1.4;
export declare class ControlPanelController {
    static controls: Readonly<{
        COMBAT: CombatControls;
        INVENTORY: InventoryControls;
        PRAYER: PrayerControls;
        EQUIPMENT: EquipmentControls;
        STATS: StatsControls;
        ANCIENTSSPELLBOOK: AncientsSpellbookControls;
        SETTINGS: SettingsControls;
    }>;
    static controller: ControlPanelController;
    desktopControls: BaseControls[];
    mobileControls: BaseControls[];
    controls: BaseControls[];
    selectedControl: BaseControls;
    width: number;
    height: number;
    private boostPanel;
    isUsingExternalUI: boolean;
    constructor();
    getTabScale(): number;
    boostPosition(): {
        x: number;
        y: number;
    };
    tabPosition(i: number): TabPosition;
    cursorMovedTo(e: MouseEvent): void;
    controlPanelRightClick(e: MouseEvent): boolean;
    controlPanelClickUp(e: MouseEvent): boolean;
    setActiveControl(index: keyof ((typeof ControlPanelController)["controls"])): void;
    controlPanelClickDown(e: MouseEvent): boolean;
    controlPosition(control: BaseControls): Location;
    onWorldTick(): void;
    draw(context: CanvasRenderingContext2D): void;
}
export {};
