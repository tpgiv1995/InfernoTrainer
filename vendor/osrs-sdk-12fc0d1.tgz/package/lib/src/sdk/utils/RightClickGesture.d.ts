export declare const DRAG_THRESHOLD_PX = 4;
export type RightClickResult = "click" | "drag" | "none";
/**
 * Tracks one right-button press so a stationary release opens the context menu
 * while a moving press rotates the camera (RuneLite "right click moves camera").
 */
export declare class RightClickGesture {
    private startX;
    private startY;
    private dragged;
    get dragging(): boolean;
    begin(x: number, y: number): void;
    isDragging(x: number, y: number): boolean;
    end(x: number, y: number): RightClickResult;
}
