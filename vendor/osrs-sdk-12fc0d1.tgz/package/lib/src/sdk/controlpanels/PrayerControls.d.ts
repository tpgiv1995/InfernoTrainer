import type { BasePrayer } from "../BasePrayer";
import { BaseControls } from "./BaseControls";
import { ControlPanelController } from "../ControlPanelController";
export declare class PrayerControls extends BaseControls {
    hasQuickPrayersActivated: boolean;
    blankPanelImage: HTMLImageElement;
    private bookIcons;
    /** The prayer in each of the 30 book slots, following Settings.prayerLayout when set. */
    slotPrayers(): (BasePrayer | null)[];
    /** Panel-relative slot origin in unscaled panel pixels; the drawn icon is 37x37 from here. */
    static slotOrigin(index: number): {
        x: number;
        y: number;
    };
    private prayerAt;
    hoverAction(x: number, y: number): {
        text: string;
        fillStyle: string;
    }[];
    get panelImageReference(): string;
    get tabImageReference(): string;
    get keyBinding(): string;
    deactivateAllPrayers(): void;
    private quickList;
    quickPrayerSetup: boolean;
    /** The saved quick-prayer set (localStorage "quickPrayers"); default Protect from Magic + Mystic Vigour. */
    quickPrayers(): string[];
    private saveQuickPrayers;
    beginQuickPrayerSetup(): void;
    endQuickPrayerSetup(): void;
    /** Setup mode click: add or remove a prayer; adding drops any prayer in the set that conflicts with it. */
    toggleQuickPrayer(prayer: BasePrayer): void;
    activateQuickPrayers(): void;
    panelClickDown(x: number, y: number): void;
    get isAvailable(): boolean;
    draw(context: any, ctrl: ControlPanelController, x: number, y: number): void;
}
