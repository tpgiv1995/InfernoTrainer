/**
 * Prayer book layouts: 30 slots (5 columns x 6 rows) holding a prayer's display
 * name or "" for an empty slot. `null` means the stock book order.
 */
export type PrayerLayout = string[];
export declare const PRAYER_LAYOUT_COLUMNS = 5;
export declare const PRAYER_LAYOUT_ROWS = 6;
/** The reference RuneLite prayer book (screenshot 2026-09-08): hidden prayers stay blank. */
export declare const V3_PRAYER_LAYOUT: PrayerLayout;
/**
 * The V3 Inferno Sim book. Deadeye and Mystic Vigour permanently replace Eagle Eye and Mystic Might (wiki), so the
 * book holds Deadeye in Eagle Eye's slot and Mystic Vigour where Mystic Might would sit (Augury's old slot here,
 * the account has no Augury). No duplicates.
 */
export declare const V3_INFERNO_PRAYER_LAYOUT: PrayerLayout;
export declare function isValidPrayerLayout(layout: unknown): layout is PrayerLayout;
