/**
 * Prayer book icons cut from the stock panel image, keyed by the prayer's display
 * name (class names are minified in production), so a custom layout can draw each prayer in any slot.
 */
export declare const PRAYER_BOOK_ICONS: Record<string, string>;
