import * as THREE from "three";
import { Location3 } from "../Location";
import { Model } from "./Model";
/** Uses the cache model after its verified preload succeeds, otherwise keeps a legacy model live. */
export declare class FallbackModel implements Model {
    private primary;
    private fallback;
    private active;
    private selection;
    private fallbackWasDrawn;
    constructor(primary: Model, fallback: Model);
    getPrimaryModel(): Model;
    /**
     * Resolve which model to use, exactly once. Prefer the cache-render primary;
     * only fall back to the legacy GLTF models if the primary fails. A fallback
     * that cannot load - e.g. a legacy item whose static GLB was never published
     * to the asset host, which 404s - must NOT be fatal (it is a fallback), so its
     * preload errors are logged and swallowed rather than rejecting the load.
     */
    private ensureSelected;
    draw(scene: THREE.Scene, clockDelta: number, tickPercent: number, location: Location3, rotation: number, pitch: number, visible: boolean, modelOffsets: Location3[]): void;
    destroy(scene: THREE.Scene): void;
    getWorldPosition(): THREE.Vector3;
    getLogicalHeight(): number | null;
    preload(): Promise<void>;
}
