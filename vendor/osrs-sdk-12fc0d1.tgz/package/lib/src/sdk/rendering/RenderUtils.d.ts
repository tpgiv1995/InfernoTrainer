import * as THREE from "three";
export declare const drawLineOnTop: (mesh: THREE.Line, renderOrder: number) => void;
export declare const drawLineNormally: (mesh: THREE.Line) => void;
