import * as THREE from "three";
import { Model } from "./Model";
import { Renderable } from "../Renderable";
import { Location3 } from "../Location";
export declare class TileMarkerModel implements Model {
    private renderable;
    static forRenderable(r: Renderable, renderOrder?: number | null): TileMarkerModel;
    private outline;
    private lineMaterial;
    constructor(renderable: Renderable, renderOrder: number | null);
    draw(scene: THREE.Scene, clockDelta: number, tickPercent: number, location: Location3, angleRadians: number, pitchRadians: number, visible: boolean, modelOffsets: Location3[]): void;
    destroy(scene: THREE.Scene): void;
    getWorldPosition(): THREE.Vector3;
    preload(): Promise<void>;
}
