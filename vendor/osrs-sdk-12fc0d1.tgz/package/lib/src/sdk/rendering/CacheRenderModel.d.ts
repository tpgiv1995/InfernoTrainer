import * as THREE from "three";
import { Location3 } from "../Location";
import { Renderable, RenderableListener } from "../Renderable";
import { CacheRenderBundle } from "./CacheRenderBundle";
import { CacheRenderReference, CacheRenderSpotAnim } from "./CacheRenderReference";
import { Model } from "./Model";
import type { CacheRenderPayload, CacheRenderRawFrame } from "../../cache-render-format";
type RawFrame = CacheRenderRawFrame;
type Payload = CacheRenderPayload;
export declare function cachedPayload(bundle: CacheRenderBundle, assetId: string): Promise<Payload>;
export declare function mergePayloads(payloads: Payload[]): Payload;
type TransformSelection = {
    indices: Set<number>;
    include: boolean;
};
/** Apply one legacy cache frame to a composed model.
 *
 * `selection` mirrors the client's two-pass animate2 operation: origin slots
 * always run, while other transform slots are selected by the primary
 * sequence's opcode-3 interleave list.
 */
export declare function applyRawFrame(positions: Float32Array, groups: number[][], sourceVertices: number[], frame: RawFrame, selection?: TransformSelection, alphas?: Float32Array, alphaGroups?: number[][]): void;
export declare function applyBlendedRawFrames(positions: Float32Array, groups: number[][], sourceVertices: number[], primary: RawFrame, pose: RawFrame, interleave: number[], alphas?: Float32Array, alphaGroups?: number[][]): void;
export declare function decodeCacheRenderPayload(bytes: ArrayBuffer): Payload;
export declare function advanceAnimationTimeForDraw(animationTime: number, clockDelta: number, startsOnThisDraw: boolean): number;
export type CacheRenderModelOptions = {
    /** Delay applied to every cache-authored animation frame sound. */
    frameSoundDelayMs?: number;
    /** Called once when a spotanim-only renderable reaches the end of its sequence. */
    onSpotAnimComplete?: () => void;
    /**
     * Optional additional root yaw in radians. Cache spotanims used as
     * standalone world graphics use a zero-degree basis, while spotanims used
     * as projectile models share the actor/model cache basis.
     */
    basisRotation?: number;
};
/** Three.js implementation for decoded cache geometry. Cache extraction owns the conversion from OSRS frames to this payload. */
export declare class CacheRenderModel implements Model, RenderableListener {
    private renderable;
    private reference;
    private options;
    private root;
    private mesh;
    private ready;
    private lastPose;
    private activeAnimation;
    private animations;
    private poseMap;
    private animationTime;
    private animationStartsOnNextDraw;
    private poseAnimationTime;
    private animationPlaying;
    private animationCanBlend;
    private frameSoundPlayer;
    private spotFrameSoundPlayers;
    private frameSoundsReady;
    private basePositions;
    private baseAlphas;
    private vertexGroups;
    private alphaGroups;
    private sourceVertices;
    private logicalHeight;
    private animayaGroups;
    private animayaScales;
    private spotAnims;
    private activeSpotAnims;
    private spotAnimClock;
    private spotAnimStarts;
    private spotAnimPlacements;
    private spotAnimCompletionNotified;
    private outline;
    private trueTile;
    private clickbox;
    private modelGeneration;
    private meshGeneration;
    constructor(renderable: Renderable, reference: CacheRenderReference, options?: CacheRenderModelOptions);
    static forRenderable(renderable: Renderable, reference: CacheRenderReference, options?: CacheRenderModelOptions): CacheRenderModel;
    spotAnimChanged(spotAnims: CacheRenderSpotAnim[]): void;
    private setActiveSpotAnims;
    private currentSpotAnims;
    animationChanged(id: number, blend: boolean): Promise<void>;
    modelChanged(): void;
    preload(): Promise<void>;
    private ensureLoaded;
    draw(scene: THREE.Scene, clockDelta: number, _tickPercent: number, location: Location3, rotation: number, pitch: number, visible: boolean, modelOffsets: Location3[]): void;
    private updateLogicalHeight;
    getLogicalHeight(): number;
    destroy(scene: THREE.Scene): void;
    getWorldPosition(): THREE.Vector3;
}
export {};
