import { CacheRenderReference } from "./CacheRenderReference";
import type { CacheRenderBundleManifest } from "../../cache-render-format";
export { CACHE_RENDER_BUNDLE_SCHEMA_VERSION } from "../../cache-render-format";
export type { CacheRenderAsset, CacheRenderBundleManifest, CacheRenderScene, CacheRenderScenePlacement } from "../../cache-render-format";
export declare class CacheRenderBundleError extends Error {
    readonly code: "manifest" | "integrity" | "missing-asset" | "network";
    constructor(code: "manifest" | "integrity" | "missing-asset" | "network", message: string);
}
export declare function validateCacheRenderBundleManifest(value: any): CacheRenderBundleManifest;
export declare class CacheRenderBundle {
    readonly baseUrl: string;
    readonly manifest: CacheRenderBundleManifest;
    private constructor();
    static load(manifestUrl: string): Promise<CacheRenderBundle>;
    assetIds(reference: CacheRenderReference): string[];
    /**
     * The default body (head, jaw, torso, arms, hands, legs, feet) goes under the equipment, like the game's client:
     * a kit part is hidden only while an item that really has a model occupies or hides its slot. An item with no model
     * therefore leaves its body part showing instead of a hole.
     */
    private withBaseKit;
    spotAnimIds(reference: CacheRenderReference): string[];
    sharedAssetIds(reference: CacheRenderReference): string[];
    allSpotAnimIds(): string[];
    fetchAsset(id: string): Promise<ArrayBuffer>;
    fetchSoundEffects(): Promise<ArrayBuffer>;
    private fetchManifestAsset;
}
/** Runtime configuration. Set `manifestUrl` to a locally extracted bundle to override the hosted default. */
export declare class CacheRender {
    private static manifestUrl;
    private static bundlePromise;
    static configure(manifestUrl: string | null): void;
    static isConfigured(): boolean;
    static bundle(): Promise<CacheRenderBundle>;
}
