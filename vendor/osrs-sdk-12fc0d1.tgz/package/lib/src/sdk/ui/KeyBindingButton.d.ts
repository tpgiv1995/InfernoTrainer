import { Component } from "./Component";
export declare class KeyBindingButton implements Component {
    private label;
    private xOffset;
    private yOffset;
    private isActive;
    private onClick;
    private overlay;
    constructor(label: () => string, xOffset: number, yOffset: number, isActive: () => boolean, onClick: () => void, overlay: HTMLImageElement);
    draw(context: CanvasRenderingContext2D, scale: number, panelX: number, panelY: number): void;
    onPanelClick(x: number, y: number): boolean;
    onMouseMove(x: number, y: number): boolean;
}
