import { Component } from "./Component";
export declare class ToggleButton implements Component {
    private label;
    private xOffset;
    private yOffset;
    private isActive;
    private onClick;
    private activeButtonImage;
    private inactiveButtonImage;
    private overlayInactive;
    constructor(label: string, xOffset: number, yOffset: number, isActive: () => boolean, onClick: () => void, activeButtonImage?: HTMLImageElement, inactiveButtonImage?: HTMLImageElement, overlayInactive?: boolean);
    draw(context: CanvasRenderingContext2D, scale: number, panelX: number, panelY: number): void;
    onPanelClick(x: number, y: number): boolean;
    onMouseMove(x: number, y: number): boolean;
}
