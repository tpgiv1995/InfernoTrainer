import { Component } from "./Component";
export declare class Button implements Component {
    private label;
    private xOffset;
    private yOffset;
    private onClick;
    private activeButtonImage;
    private inactiveButtonImage;
    private overlayInactive;
    private hovered;
    constructor(label: string, xOffset: number, yOffset: number, onClick: () => void, activeButtonImage?: HTMLImageElement, inactiveButtonImage?: HTMLImageElement, overlayInactive?: boolean);
    draw(context: CanvasRenderingContext2D, scale: number, panelX: number, panelY: number): void;
    private _isMouseOver;
    onPanelClick(x: number, y: number): boolean;
    onMouseMove(x: number, y: number): boolean;
}
