/** Visual-only copy of the RuneLite modern-layout chat buttons along the bottom-left. */
export declare class ChatStrip {
    /** Unscaled width of the whole strip: seven buttons, gaps, and the clock. */
    static readonly TOTAL_W: number;
    /**
     * @param maxRight the left edge of the tab row; the strip shrinks to stay left of it
     * and hides if that would make it unreadable.
     */
    static draw(context: CanvasRenderingContext2D, width: number, height: number, scale: number, maxRight?: number): void;
}
