import { Unit } from "../Unit";
import { BarrageSpell } from "./BarrageSpell";
import { ProjectileOptions } from "./Projectile";
import { AttackBonuses } from "../gear/Weapon";
import { ItemName } from "../ItemName";
import { Sound } from "../utils/SoundCache";
export declare class BloodBarrageSpell extends BarrageSpell {
    constructor(projectileRules?: ProjectileOptions);
    get attackSound(): Sound;
    get itemName(): ItemName;
    get baseDamage(): number;
    attack(from: Unit, to: Unit, bonuses?: AttackBonuses, options?: ProjectileOptions): boolean;
    private leech;
}
