import type { Unit } from "../Unit";
import { BarrageSpell } from "./BarrageSpell";
import { ProjectileOptions } from "./Projectile";
import { AttackBonuses } from "../gear/Weapon";
import { ItemName } from "../ItemName";
import { Sound } from "../utils/SoundCache";
export declare class IceBarrageSpell extends BarrageSpell {
    constructor(projectileRules?: ProjectileOptions);
    get attackSound(): Sound;
    get itemName(): ItemName;
    attack(from: Unit, to: Unit, bonuses?: AttackBonuses, options?: ProjectileOptions): boolean;
}
