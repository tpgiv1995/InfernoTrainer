/** Browser- and Node-neutral contract for a compiled cache-render bundle. */
export declare const CACHE_RENDER_BUNDLE_SCHEMA_VERSION = 1;
export type CacheRenderAsset = {
    file: string;
    sha256: string;
    bytes?: number;
};
export type CacheRenderScenePlacement = {
    assetId: string;
    x: number;
    y: number;
    plane: number;
    width?: number;
    height?: number;
};
export type CacheRenderScene = {
    regionId: number;
    /** Build-time source recipe. It is omitted from published compiled bundles. */
    placements?: CacheRenderScenePlacement[];
    mirrorY?: boolean;
    width?: number;
    height?: number;
    compiledAssets: {
        terrain?: string;
        opaque?: string;
        transparent?: string;
    };
};
export type CacheRenderBundleManifest = {
    schemaVersion: number;
    bundleVersion: string;
    cache: {
        revision: number;
        source: string;
        contentHash: string;
    };
    assets: Record<string, CacheRenderAsset>;
    references: Record<string, string[]>;
    scenes?: Record<string, CacheRenderScene>;
    playerItems?: Record<string, string>;
    /** Per player item: whether the cache has a worn model for it, and the appearance slots it occupies or hides. */
    playerItemInfo?: Record<string, {
        name: string;
        hasModel: boolean;
        slots: number[];
    }>;
    /** Default identity-kit body parts (head, jaw, torso, arms, hands, legs, feet) and the appearance slot each one fills. */
    playerKit?: Record<string, {
        asset: string;
        slot: number;
    }>;
    spotAnims?: Record<string, string>;
    sharedAssets?: {
        playerAnimations?: string;
    };
    soundEffects?: CacheRenderAsset;
};
/** Structural validation shared by the asset writer and browser loader. */
export declare function isCacheRenderBundleManifest(value: any): value is CacheRenderBundleManifest;
