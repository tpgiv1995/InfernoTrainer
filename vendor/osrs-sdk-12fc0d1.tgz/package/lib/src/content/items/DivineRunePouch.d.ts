import { Item } from "../../sdk/Item";
import { ItemName } from "../../sdk/ItemName";
export interface PouchStack {
    rune: "Water" | "Death" | "Blood" | "Soul" | string;
    id: number;
    quantity: number;
}
/**
 * Divine rune pouch (l): four rune stacks (the saved Inferno v2 setup: 15,000 water, 2,525 death, 8,000 blood,
 * 8,000 soul). Ice Barrage and Blood Barrage spend their runes from it (V3 rules) and refuse to cast at zero.
 * Wiki costs: Ice Barrage 6 water + 4 death + 2 blood; Blood Barrage 4 death + 4 blood + 1 soul.
 */
export declare class DivineRunePouch extends Item {
    inventorySprite: HTMLImageElement;
    stacks: PouchStack[];
    constructor(stacks?: PouchStack[]);
    get inventoryImage(): string;
    get itemName(): ItemName;
    get weight(): number;
    quantity(rune: string): number;
    canAfford(cost: Record<string, number>): boolean;
    /** Spends the runes; returns false (and spends nothing) when the pouch cannot pay. */
    spendRunes(cost: Record<string, number>): boolean;
    /** Casts left of the spell with this cost, shown on the inventory icon. */
    castsLeft(cost: Record<string, number>): number;
    /** Small number drawn over the icon: Ice Barrage casts left. */
    get overlayText(): string | null;
    describe(): string;
}
