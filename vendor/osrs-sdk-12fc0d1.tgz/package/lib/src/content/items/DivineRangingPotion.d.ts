import { ItemName } from "../../sdk/ItemName";
import { Player } from "../../sdk/Player";
import { Potion } from "../../sdk/gear/Potion";
/** See drink(). */
export declare class DivineRangingPotion extends Potion {
    oneDose: HTMLImageElement;
    twoDose: HTMLImageElement;
    threeDose: HTMLImageElement;
    fourDose: HTMLImageElement;
    constructor(doses?: number);
    get inventoryImage(): string;
    get itemName(): ItemName;
    /**
     * Divine ranging potion: Ranged +4 and +10%, costs 10 Hitpoints (needs more than 10), and the boost does not
     * decay for 5 minutes (500 ticks), then Ranged drops back to base. A Saradomin brew still drains Ranged
     * normally; drinking again in the window re-boosts to 112 and restarts the 5 minutes.
     */
    inventoryLeftClick(player: Player): void;
    drink(player: Player): void;
    updateInventorySprite(): void;
}
