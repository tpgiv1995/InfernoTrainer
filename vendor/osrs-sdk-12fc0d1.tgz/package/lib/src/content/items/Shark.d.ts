import { Food } from "../../sdk/gear/Food";
import { ItemName } from "../../sdk/ItemName";
export declare class Shark extends Food {
    healAmount: number;
    inventorySprite: HTMLImageElement;
    get inventoryImage(): string;
    get itemName(): ItemName;
    get weight(): number;
}
