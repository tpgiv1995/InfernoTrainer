import { ItemName } from "../../sdk/ItemName";
import { Player } from "../../sdk/Player";
import { Potion } from "../../sdk/gear/Potion";
export declare class PrayerRegenerationPotion extends Potion {
    oneDose: HTMLImageElement;
    twoDose: HTMLImageElement;
    threeDose: HTMLImageElement;
    fourDose: HTMLImageElement;
    constructor(doses?: number);
    get inventoryImage(): string;
    get itemName(): ItemName;
    /** One Prayer point every 12 ticks for 8 minutes (800 ticks) per dose; doses add up. */
    drink(player: Player): void;
    updateInventorySprite(): void;
}
