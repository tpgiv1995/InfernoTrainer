import { ItemName } from "../../sdk/ItemName";
import { Player } from "../../sdk/Player";
import { Potion } from "../../sdk/gear/Potion";
/** See drink(). */
export declare class RangingPotion extends Potion {
    oneDose: HTMLImageElement;
    twoDose: HTMLImageElement;
    threeDose: HTMLImageElement;
    fourDose: HTMLImageElement;
    constructor(doses?: number);
    get inventoryImage(): string;
    get itemName(): ItemName;
    /**
     * Ranging potion: Ranged +4 and +10% of the base level (99 -> 112), no Hitpoints cost. Like any boost it decays
     * one level a minute (Player.v3Tick), a Saradomin brew drains it, and drinking again re-boosts.
     */
    drink(player: Player): void;
    updateInventorySprite(): void;
}
