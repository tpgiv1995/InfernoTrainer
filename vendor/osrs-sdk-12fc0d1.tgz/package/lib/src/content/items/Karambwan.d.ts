import { Food } from "../../sdk/gear/Food";
import { ItemName } from "../../sdk/ItemName";
import { Player } from "../../sdk/Player";
export declare class Karambwan extends Food {
    healAmount: number;
    inventorySprite: HTMLImageElement;
    get inventoryImage(): string;
    get itemName(): ItemName;
    get weight(): number;
    inventoryLeftClick(player: Player): void;
}
