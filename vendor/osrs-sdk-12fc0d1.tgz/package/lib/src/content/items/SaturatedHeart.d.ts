import { Item } from "../../sdk/Item";
import { ItemName } from "../../sdk/ItemName";
import { Player } from "../../sdk/Player";
/**
 * Saturated heart: Magic +4 and +10% for 5 minutes, the boost does not decay, a Saradomin brew's Magic drain
 * cancels it, and it has a 5 minute cooldown. The state lives on the Player (useSaturatedHeart).
 */
export declare class SaturatedHeart extends Item {
    inventorySprite: HTMLImageElement;
    constructor();
    get hasInventoryLeftClick(): boolean;
    inventoryLeftClick(player: Player): void;
    get inventoryImage(): string;
    get itemName(): ItemName;
    get weight(): number;
}
