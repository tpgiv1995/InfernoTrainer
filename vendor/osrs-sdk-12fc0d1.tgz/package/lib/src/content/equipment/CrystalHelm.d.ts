import { Helmet } from "../../sdk/gear/Helmet";
import { ItemName } from "../../sdk/ItemName";
export declare class CrystalHelm extends Helmet {
    /** OSRS cache item id: the player is drawn from the cache model of every worn item. */
    get cacheItemId(): number;
    inventorySprite: HTMLImageElement;
    get itemName(): ItemName;
    get weight(): number;
    get inventoryImage(): string;
    constructor();
    Model: string;
    get model(): string;
}
