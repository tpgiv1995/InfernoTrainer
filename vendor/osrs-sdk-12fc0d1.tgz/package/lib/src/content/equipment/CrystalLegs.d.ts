import { Legs } from "../../sdk/gear/Legs";
import { ItemName } from "../../sdk/ItemName";
export declare class CrystalLegs extends Legs {
    /** OSRS cache item id: the player is drawn from the cache model of every worn item. */
    get cacheItemId(): number;
    inventorySprite: HTMLImageElement;
    get inventoryImage(): string;
    get itemName(): ItemName;
    get weight(): number;
    constructor();
    Model: string;
    get model(): string;
}
