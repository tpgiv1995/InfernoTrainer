import { Chest } from "../../sdk/gear/Chest";
import { ItemName } from "../../sdk/ItemName";
/** V3 Inferno kit item. Stats are the OSRS Wiki values the calculator (tools/inferno_gear.py) reads. */
export declare class BandosChestplate extends Chest {
    /** OSRS cache item id: the player is drawn from the cache model of every worn item. */
    get cacheItemId(): number;
    inventorySprite: HTMLImageElement;
    get inventoryImage(): string;
    get itemName(): ItemName;
    get weight(): number;
    constructor();
}
