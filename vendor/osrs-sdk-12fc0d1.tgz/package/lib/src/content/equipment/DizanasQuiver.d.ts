import { Cape } from "../../sdk/gear/Cape";
import { ItemName } from "../../sdk/ItemName";
import { Equipment } from "../../sdk/Equipment";
export declare class DizanasQuiver extends Cape {
    /** OSRS cache item id: the player is drawn from the cache model of every worn item. */
    get cacheItemId(): number;
    inventorySprite: HTMLImageElement;
    get inventoryImage(): string;
    get itemName(): ItemName;
    get weight(): number;
    constructor();
    updateBonuses(gear: Equipment[]): void;
    get model(): string;
    Model: string;
}
