import { BasePrayer, PrayerGroups } from "../../sdk/BasePrayer";
/** Deadeye: Ranged accuracy and strength x1.18, Defence +5%. Factors live in the central table in sdk/V3Rules.ts (the calculator's PRAYERS table). */
export declare class Deadeye extends BasePrayer {
    get name(): string;
    get groups(): PrayerGroups[];
    levelRequirement(): number;
    isOverhead(): boolean;
    feature(): string;
    drainRate(): number;
}
