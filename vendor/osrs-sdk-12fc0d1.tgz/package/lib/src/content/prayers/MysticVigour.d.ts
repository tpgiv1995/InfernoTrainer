import { BasePrayer, PrayerGroups } from "../../sdk/BasePrayer";
/** Mystic Vigour: Magic accuracy x1.18, Magic damage +3%, Magic defence x1.18, Defence +5%. Factors live in the central table in sdk/V3Rules.ts (the calculator's PRAYERS table). */
export declare class MysticVigour extends BasePrayer {
    get name(): string;
    get groups(): PrayerGroups[];
    levelRequirement(): number;
    isOverhead(): boolean;
    feature(): string;
    drainRate(): number;
}
