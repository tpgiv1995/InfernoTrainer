import { RangedWeapon } from "../../sdk/weapons/RangedWeapon";
import { ItemName } from "../../sdk/ItemName";
import { Unit } from "../../sdk/Unit";
import { AttackBonuses } from "../../sdk/gear/Weapon";
import { AttackStyle, AttackStyleTypes } from "../../sdk/AttackStylesController";
import { ProjectileOptions } from "../../sdk/weapons/Projectile";
import { Sound } from "../../sdk/utils/SoundCache";
import { PlayerAnimationIndices } from "../../sdk/rendering/GLTFAnimationConstants";
export declare class Blowpipe extends RangedWeapon {
    /** OSRS cache item id: the player is drawn from the cache model of every worn item. */
    get cacheItemId(): number;
    constructor();
    calculateHitDelay(distance: number): number;
    attackStyles(): AttackStyle[];
    attackStyleCategory(): AttackStyleTypes;
    defaultStyle(): AttackStyle;
    get attackRange(): 7 | 5;
    get attackSpeed(): 2 | 3;
    get weight(): number;
    specialAttack(from: Unit, to: Unit, bonuses?: AttackBonuses, options?: ProjectileOptions): void;
    _damageMultiplier(from: Unit, to: Unit, bonuses: AttackBonuses): 1 | 1.5;
    _accuracyMultiplier(from: Unit, to: Unit, bonuses: AttackBonuses): 1 | 2;
    get itemName(): ItemName;
    get isTwoHander(): boolean;
    hasSpecialAttack(): boolean;
    get inventoryImage(): string;
    get attackSound(): Sound;
    get specialAttackSound(): Sound;
    Model: string;
    get model(): string;
    get attackAnimationId(): PlayerAnimationIndices;
    ProjectileModel: string;
    get projectileModel(): string;
}
