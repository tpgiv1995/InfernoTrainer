import { AttackStyle, AttackStyleTypes } from "../../sdk/AttackStylesController";
import { AttackBonuses } from "../../sdk/gear/Weapon";
import { ItemName } from "../../sdk/ItemName";
import { Unit } from "../../sdk/Unit";
import { BarrageSpell } from "../../sdk/weapons/BarrageSpell";
import { MeleeWeapon } from "../../sdk/weapons/MeleeWeapon";
export declare class AncientStaff extends MeleeWeapon {
    autocastSpell: BarrageSpell;
    constructor();
    get weight(): number;
    attack(from: Unit, to: Unit, bonuses?: AttackBonuses): boolean;
    attackStyles(): AttackStyle[];
    attackStyleCategory(): AttackStyleTypes;
    defaultStyle(): AttackStyle;
    get itemName(): ItemName;
    get isTwoHander(): boolean;
    hasSpecialAttack(): boolean;
    get attackRange(): 10 | 1;
    get attackSpeed(): number;
    get inventoryImage(): string;
}
