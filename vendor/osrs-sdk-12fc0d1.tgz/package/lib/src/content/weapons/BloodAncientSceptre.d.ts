import { AttackStyle, AttackStyleTypes } from "../../sdk/AttackStylesController";
import { AttackBonuses } from "../../sdk/gear/Weapon";
import { ItemName } from "../../sdk/ItemName";
import { Unit } from "../../sdk/Unit";
import { BarrageSpell } from "../../sdk/weapons/BarrageSpell";
import { MeleeWeapon } from "../../sdk/weapons/MeleeWeapon";
/**
 * Blood ancient sceptre. It autocasts Ice Barrage; a Blood Barrage picked from the spellbook heals the player
 * and, while the sceptre is wielded, can overheal up to 10% over base Hitpoints (see BloodBarrageSpell).
 * Stats are the OSRS Wiki values used by tools/inferno_gear.py.
 */
export declare class BloodAncientSceptre extends MeleeWeapon {
    /** OSRS cache item id: the player is drawn from the cache model of every worn item. */
    get cacheItemId(): number;
    get attackAnimationId(): number;
    autocastSpell: BarrageSpell;
    constructor();
    get weight(): number;
    attack(from: Unit, to: Unit, bonuses?: AttackBonuses): boolean;
    attackStyles(): AttackStyle[];
    attackStyleCategory(): AttackStyleTypes;
    defaultStyle(): AttackStyle;
    get itemName(): ItemName;
    get isTwoHander(): boolean;
    hasSpecialAttack(): boolean;
    get attackRange(): 10 | 1;
    get attackSpeed(): 4 | 5;
    get inventoryImage(): string;
}
